## Algumas informações sobre Aprendizado de Máquina no JupyterLab:

Este é um exemplo da biblioteca seaborn.

# Abaixo, link do mybinder para rodar este Jupyter notebook:
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/odairjosebellini/aprendizado-de-maquina/master)
